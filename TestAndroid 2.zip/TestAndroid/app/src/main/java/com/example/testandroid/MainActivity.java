package com.example.testandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText et1user,et2pass,et3name;
    Button log;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et1user = findViewById(R.id.etuser);
        et2pass = findViewById(R.id.etpass);
        et3name = findViewById(R.id.etname);
        log = findViewById(R.id.btnlogin);

        log.setOnClickListener(this);


    }
    @Override
    public void onClick(View view) {
//        if (et1user.getText().toString().equals("student1") || et2pass.getText().toString().equals("123456")) {
//            return;}
//
//
//            if (et3name.getText().toString().equalsIgnoreCase("")) {
//                Toast.makeText(MainActivity.this, "Please Enter Student Name ", Toast.LENGTH_SHORT).show();
//                return;
//            }
//            if (et1user.getText().toString().equalsIgnoreCase("")) {
//                Toast.makeText(MainActivity.this, "Please Enter UserName ", Toast.LENGTH_SHORT).show();
//                return;
//            }
//
//            if (et2pass.getText().toString().equalsIgnoreCase("")) {
//                Toast.makeText(MainActivity.this, "Please Enter Password ", Toast.LENGTH_SHORT).show();
//                return;
//            }
//            if (!(et1user.getText().toString().equalsIgnoreCase("student1"))) {
//                Toast.makeText(MainActivity.this, "Invaild UserName Try Again! ", Toast.LENGTH_SHORT).show();
//                return;
//            }
//            if (!(et2pass.getText().toString().equalsIgnoreCase("123456"))) {
//                Toast.makeText(MainActivity.this, "Invaild Password ", Toast.LENGTH_SHORT).show();
//                return;
//            }
//            Intent intent = new Intent(MainActivity.this, Main2Activity.class);
//            intent.putExtra("studentName", et3name.getText().toString());
//            startActivity(intent);
//
//        }
//    }

        if (et1user.getText().toString().equals("student1") || et2pass.getText().toString().equals("123456")) {
            Intent act = new Intent(getApplicationContext(), Main2Activity.class);
            act.putExtra("name", et1user.getText().toString());
            //starting an intent
            startActivity(act);
            finish();

            //correcct password
        } else {
            Toast.makeText(getApplicationContext(), "Invalid username or password", Toast.LENGTH_SHORT).show();
            //wrong password
        }

    }}
