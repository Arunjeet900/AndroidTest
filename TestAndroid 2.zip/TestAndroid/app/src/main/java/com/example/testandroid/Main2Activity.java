package com.example.testandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class Main2Activity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener {

    RadioGroup rdgrp;
    RadioButton rbgrad,rbungrad;
    Spinner spin;
    EditText et1fees,et2hours,et3totalfees,et4totalhours;
    CheckBox cb1acc,cb2med;
    TextView wel;

    Button btn1add;
    double fe;
    double hour;
    int[] fees = {200,100,1000,2000,700};
    int[] hours = {6,5,5,7,4};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);



        String  name =  getIntent().getStringExtra("studentName");
        wel=findViewById(R.id.welview);
        wel.setText("Welcome "+name);

        rdgrp =findViewById(R.id.radiogroup);
        rbgrad = findViewById(R.id.rb1grad);
        rbungrad = findViewById(R.id.rb2ungrad);
        spin = findViewById(R.id.spinner);
        et1fees = findViewById(R.id.etfees);
        et2hours = findViewById(R.id.ethrs);
        et3totalfees = findViewById(R.id.ettotalfees);
        et4totalhours = findViewById(R.id.ettotalhours);
        btn1add = findViewById(R.id.btnadd);
        cb1acc = findViewById(R.id.cbacc);
        cb2med = findViewById(R.id.cbmed);


        List<String> courses = new ArrayList<>();
        courses.add("Java");
        courses.add("Swift");
        courses.add("iOS");
        courses.add("Android");
        courses.add("Database");

        ArrayAdapter<String> proAdapter= new ArrayAdapter<>(this,R.layout.support_simple_spinner_dropdown_item,courses);
        proAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        spin.setAdapter(proAdapter);
        spin.setOnItemSelectedListener(this);
        btn1add.setOnClickListener(this);


    }


    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        fe = new Double(fees[i]);
        et1fees.setText(String.valueOf(fe));
        hour = new Double(hours[i]);
        et2hours.setText(String.valueOf(hour));


    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {




    }

     public void onClick(View view) {
        if(!et1fees.getText().equals(""))
        {
            Double totalfee = Double.parseDouble(et1fees.getText().toString());

            et3totalfees.setText(String.valueOf(totalfee));

            Double  totalhours  = Double.parseDouble(et2hours.getText().toString());

            et4totalhours.setText(String.valueOf(totalhours));
        }



     }


}
